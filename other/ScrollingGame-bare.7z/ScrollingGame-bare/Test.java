public class Test
{
    public static void main(String[] args){
        //long a = System.currentTimeMillis();
        int time = 100;
        for(int i=0;i<4001; i+=100){
        System.out.println( i % 2000);
    }
        System.out.println((int)1000 / 3);
    }
}
